import AppRouter from '../AppRouter';
import './App.css';

export default function App() {
  return (
    <div className="w-screen h-screen">
      <AppRouter />
    </div>
  );
}
